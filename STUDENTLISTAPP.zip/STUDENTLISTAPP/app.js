const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const app = express();

// Set up view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// enable static files
app.use(express.static('public'));
// enable form processing
app.use(express.urlencoded({ extended: true }));
// Hardcoded MySQL Connection Pool 

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'RP738964$',
  database: 'student_db',
});

// Test Database Connection
db.connect((err) => {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }
    console.log('Connected to MySQL Database successfully!');
});

function formatDateForInput(value) {
    if (!value) return '';

    if (value instanceof Date) {
        return value.toISOString().split('T')[0];
    }

    const text = String(value);
    if (text.includes('T')) return text.split('T')[0];
    if (text.includes(' ')) return text.split(' ')[0];
    return text;
}

// --- ROUTES ---

// 1. GET: Render Main Student List (index.ejs)
app.get('/', (req, res) => {
    db.query('SELECT * FROM students', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Database error.");
        }
        res.render('index', { students: results });
    });
});

// 2. GET: Render Add Student Form (addStudents.ejs)
app.get('/add-student', (req, res) => {
    res.render('addStudents');
});

// 3. POST: Handle Add Student Form Submission
app.post('/add-student', (req, res) => {
    const { student_name, student_image, dob, contact } = req.body;
    const query = 'INSERT INTO students (student_name, student_image, dob, contact) VALUES (?, ?, ?, ?)';
    
    db.query(query, [student_name, student_image, dob, contact], (err, result) => {
        if (err) {
            console.error(err);
            return res.send("Error inserting student record.");
        }
        res.redirect('/');
    });
});

// 4. GET: View a Single Student Profile (student.ejs)
app.get('/student/:id', (req, res) => {
    const studentId = req.params.id;
    const query = 'SELECT * FROM students WHERE id = ?';

    db.query(query, [studentId], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Database error.");
        }
        
        if (results.length > 0) {
            res.render('student', { student: results[0] });
        } else {
            res.render('student', { student: null });
        }
    });
});

// 5. GET: Render Edit Student Form (editStudents.ejs)
app.get('/edit-student/:id', (req, res) => {
    const studentId = req.params.id;
    const query = 'SELECT * FROM students WHERE id = ?';

    db.query(query, [studentId], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Database error.");
        }

        if (results.length > 0) {
            const student = {
                ...results[0],
                dob_input: formatDateForInput(results[0].dob)
            };
            res.render('editStudents', { student });
        } else {
            res.render('editStudents', { student: null });
        }
    });
});

// 6. POST: Handle Edit Student Form Submission
app.post('/edit-student/:id', (req, res) => {
    const studentId = req.params.id;
    const { student_name, student_image, dob, contact } = req.body;
    const query = 'UPDATE students SET student_name = ?, student_image = ?, dob = ?, contact = ? WHERE id = ?';

    db.query(query, [student_name, student_image, dob, contact, studentId], (err) => {
        if (err) {
            console.error(err);
            return res.send("Error updating student record.");
        }
        res.redirect('/');
    });
});

// 7. POST: Delete a Student Record
app.post('/delete-student/:id', (req, res) => {
    const studentId = req.params.id;
    const query = 'DELETE FROM students WHERE id = ?';

    db.query(query, [studentId], (err) => {
        if (err) {
            console.error(err);
            return res.send("Error deleting student record.");
        }
        res.redirect('/');
    });
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});